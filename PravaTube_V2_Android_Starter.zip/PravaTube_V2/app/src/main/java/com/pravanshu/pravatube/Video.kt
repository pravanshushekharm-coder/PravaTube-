package com.pravanshu.pravatube

data class Video(
    val id: String = "",
    val title: String = "",
    val description: String = "",
    val videoUrl: String = "",
    val audioUrl: String = "",
    val thumbnailUrl: String = "",
    val channelName: String = "PravaTube Creator",
    val ownerId: String = "",
    val views: Long = 0,
    val likes: Long = 0,
    val createdAt: Long = System.currentTimeMillis()
)
