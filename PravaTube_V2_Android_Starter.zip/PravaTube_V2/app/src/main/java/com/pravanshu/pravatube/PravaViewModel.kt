package com.pravanshu.pravatube

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.storage.FirebaseStorage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.UUID

class PravaViewModel : ViewModel() {
    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()
    private val storage = FirebaseStorage.getInstance()
    private val _user = MutableStateFlow(auth.currentUser)
    val user: StateFlow<com.google.firebase.auth.FirebaseUser?> = _user
    private val _videos = MutableStateFlow<List<Video>>(emptyList())
    val videos: StateFlow<List<Video>> = _videos
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error
    private val _status = MutableStateFlow("")
    val status: StateFlow<String> = _status

    init {
        auth.addAuthStateListener { _user.value = it.currentUser }
        db.collection("videos").orderBy("createdAt", Query.Direction.DESCENDING)
            .addSnapshotListener { snapshot, exception ->
                if (exception != null) { _error.value = exception.localizedMessage; return@addSnapshotListener }
                _videos.value = snapshot?.documents?.mapNotNull { doc ->
                    doc.toObject(Video::class.java)?.copy(id = doc.id)
                } ?: emptyList()
            }
    }

    fun register(email: String, password: String) = viewModelScope.launch {
        try {
            require(email.isNotBlank() && password.length >= 6) { "Enter valid email and password (6+ characters)." }
            auth.createUserWithEmailAndPassword(email, password).await()
            _error.value = null
        } catch (e: Exception) { _error.value = e.localizedMessage ?: "Registration failed" }
    }

    fun login(email: String, password: String) = viewModelScope.launch {
        try {
            require(email.isNotBlank() && password.isNotBlank()) { "Enter email and password." }
            auth.signInWithEmailAndPassword(email, password).await()
            _error.value = null
        } catch (e: Exception) { _error.value = e.localizedMessage ?: "Login failed" }
    }

    fun signOut() { auth.signOut() }

    fun uploadVideo(videoUri: Uri, thumbnailUri: Uri?, title: String, description: String) =
        viewModelScope.launch {
            val current = auth.currentUser ?: run { _status.value = "Please sign in first."; return@launch }
            try {
                _status.value = "Uploading video…"
                val id = UUID.randomUUID().toString()
                val videoRef = storage.reference.child("videos/${current.uid}/$id.mp4")
                videoRef.putFile(videoUri).await()
                val videoUrl = videoRef.downloadUrl.await().toString()
                var thumbnailUrl = ""
                if (thumbnailUri != null) {
                    _status.value = "Uploading thumbnail…"
                    val thumbRef = storage.reference.child("thumbnails/${current.uid}/$id.jpg")
                    thumbRef.putFile(thumbnailUri).await()
                    thumbnailUrl = thumbRef.downloadUrl.await().toString()
                }
                _status.value = "Publishing video…"
                val video = Video(
                    id = id, title = title, description = description,
                    videoUrl = videoUrl, thumbnailUrl = thumbnailUrl,
                    channelName = current.email?.substringBefore("@") ?: "Creator",
                    ownerId = current.uid
                )
                db.collection("videos").document(id).set(video).await()
                _status.value = "Video uploaded successfully!"
            } catch (e: Exception) {
                _status.value = "Upload failed: ${e.localizedMessage ?: "unknown error"}"
            }
        }

    fun like(videoId: String) = viewModelScope.launch {
        try {
            db.collection("videos").document(videoId)
                .update("likes", com.google.firebase.firestore.FieldValue.increment(1)).await()
        } catch (e: Exception) { _error.value = e.localizedMessage }
    }

    // The platform DownloadManager downloads an authorized direct media URL to public Movies/Music.
    fun download(context: Context, url: String, mimeType: String, fileName: String, audio: Boolean) {
        if (url.isBlank()) { _status.value = "No downloadable media URL is available."; return }
        val dir = if (audio) Environment.DIRECTORY_MUSIC + "/PravaTube"
                  else Environment.DIRECTORY_MOVIES + "/PravaTube"
        try {
            val request = DownloadManager.Request(Uri.parse(url))
                .setTitle(fileName)
                .setDescription("Downloading with PravaTube")
                .setMimeType(mimeType)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationInExternalPublicDir(dir, fileName)
            (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
            _status.value = "Download queued. Check your notification shade."
        } catch (e: Exception) {
            _status.value = "Could not start download: ${e.localizedMessage}"
        }
    }
}
