package com.pravanshu.pravatube

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView
import java.util.Locale

private val AppRed = Color(0xFFFF0033)
private val AppBg = Color(0xFF0F0F0F)
private val SurfaceDark = Color(0xFF212121)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PravaTubeApp() }
    }
}

@Composable
fun PravaTubeApp(vm: PravaViewModel = viewModel()) {
    val user by vm.user.collectAsState()
    val videos by vm.videos.collectAsState()
    var selectedVideo by remember { mutableStateOf<Video?>(null) }
    var tab by remember { mutableStateOf("Home") }
    var showDownloads by remember { mutableStateOf(false) }
    var searchOpen by remember { mutableStateOf(false) }
    var searchText by remember { mutableStateOf("") }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = AppRed, background = AppBg, surface = SurfaceDark,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = AppBg) {
            if (user == null) {
                AuthScreen(vm)
            } else if (showDownloads) {
                DownloadCenter(videos, onBack = { showDownloads = false })
            } else if (selectedVideo != null) {
                VideoPlayerScreen(selectedVideo!!, onBack = { selectedVideo = null }, vm = vm)
            } else {
                Scaffold(
                    containerColor = AppBg,
                    topBar = {
                        Row(
                            Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                Modifier.weight(1f).clickable { showDownloads = true },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(width = 34.dp, height = 24.dp).background(AppRed, CircleShape),
                                    contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.PlayArrow, null, tint = Color.White)
                                }
                                Spacer(Modifier.width(7.dp))
                                Text("PravaTube", fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
                                Text("  ▾", color = Color.LightGray, fontSize = 11.sp)
                            }
                            IconButton(onClick = { searchOpen = !searchOpen }) {
                                Icon(Icons.Default.Search, "Search")
                            }
                            IconButton(onClick = { showDownloads = true }) {
                                Icon(Icons.Default.Download, "Downloads")
                            }
                            IconButton(onClick = { vm.signOut() }) {
                                Icon(Icons.Default.AccountCircle, "Account")
                            }
                        }
                    },
                    bottomBar = {
                        NavigationBar(containerColor = AppBg, contentColor = Color.White) {
                            val items = listOf(
                                Triple("Home", Icons.Default.Home, "Home"),
                                Triple("Shorts", Icons.Default.Movie, "Shorts"),
                                Triple("Create", Icons.Default.AddCircle, "Create"),
                                Triple("Subscriptions", Icons.Default.Subscriptions, "Subscriptions"),
                                Triple("You", Icons.Default.Person, "You")
                            )
                            items.forEach { item ->
                                NavigationBarItem(
                                    selected = tab == item.first,
                                    onClick = { tab = item.first },
                                    icon = { Icon(item.second, contentDescription = item.third) },
                                    label = { Text(item.third, fontSize = 10.sp, maxLines = 1) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.White,
                                        selectedTextColor = Color.White,
                                        indicatorColor = SurfaceDark,
                                        unselectedIconColor = Color.LightGray,
                                        unselectedTextColor = Color.LightGray
                                    )
                                )
                            }
                        }
                    }
                ) { padding ->
                    Column(Modifier.padding(padding).fillMaxSize()) {
                        if (searchOpen) {
                            OutlinedTextField(
                                value = searchText, onValueChange = { searchText = it },
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                                placeholder = { Text("Search PravaTube") },
                                singleLine = true,
                                trailingIcon = {
                                    IconButton(onClick = { searchText = "" }) {
                                        Icon(Icons.Default.Close, "Clear")
                                    }
                                }
                            )
                        }
                        when (tab) {
                            "Create" -> UploadScreen(vm, Modifier.fillMaxSize())
                            "You" -> ProfileScreen(vm, Modifier.fillMaxSize())
                            "Shorts" -> ShortsScreen(videos, onSelect = { selectedVideo = it })
                            "Subscriptions" -> FeedScreen(
                                videos.filter { it.ownerId != user?.uid },
                                searchText, onSelect = { selectedVideo = it },
                                emptyMessage = "Videos from channels you subscribe to will appear here."
                            )
                            else -> FeedScreen(
                                videos.filter {
                                    searchText.isBlank() ||
                                    it.title.contains(searchText, true) ||
                                    it.channelName.contains(searchText, true)
                                },
                                searchText, onSelect = { selectedVideo = it },
                                emptyMessage = "No videos yet. Upload the first video to PravaTube."
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CategoryChips() {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        listOf("All", "Music", "Gaming", "News", "Live", "Podcasts").forEachIndexed { index, label ->
            Surface(
                color = if (index == 0) Color.White else SurfaceDark,
                shape = MaterialTheme.shapes.small
            ) {
                Text(label, color = if (index == 0) Color.Black else Color.White,
                    modifier = Modifier.padding(horizontal = 13.dp, vertical = 8.dp),
                    fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@Composable
fun FeedScreen(
    videos: List<Video>, searchText: String, onSelect: (Video) -> Unit,
    emptyMessage: String
) {
    LazyColumn {
        item { CategoryChips() }
        if (videos.isEmpty()) {
            item {
                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text(if (searchText.isNotBlank()) "No matching videos found." else emptyMessage,
                        color = Color.LightGray)
                }
            }
        }
        items(videos, key = { it.id }) { video -> VideoFeedCard(video, onSelect) }
    }
}

@Composable
fun VideoFeedCard(video: Video, onSelect: (Video) -> Unit) {
    Column(Modifier.fillMaxWidth().clickable { onSelect(video) }.padding(bottom = 17.dp)) {
        AsyncImage(
            model = video.thumbnailUrl.takeIf { it.isNotBlank() },
            contentDescription = video.title,
            modifier = Modifier.fillMaxWidth().height(215.dp).background(SurfaceDark),
            contentScale = ContentScale.Crop
        )
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.AccountCircle, null, tint = Color.LightGray, modifier = Modifier.size(42.dp))
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(video.title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 2)
                Text("${video.channelName} • ${video.views} views",
                    color = Color.LightGray, fontSize = 12.sp)
            }
            Icon(Icons.Default.MoreVert, null, tint = Color.LightGray)
        }
    }
}

@Composable
fun ShortsScreen(videos: List<Video>, onSelect: (Video) -> Unit) {
    if (videos.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Short videos will appear here when creators upload them.", color = Color.LightGray)
        }
    } else {
        LazyColumn {
            items(videos) { video ->
                Row(
                    Modifier.fillMaxWidth().height(170.dp).clickable { onSelect(video) }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    AsyncImage(video.thumbnailUrl, null, Modifier.width(120.dp).fillMaxHeight(), contentScale = ContentScale.Crop)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(video.title, fontWeight = FontWeight.Bold)
                        Text(video.channelName, color = Color.LightGray, fontSize = 12.sp)
                        Text("Open short  ›", color = AppRed, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AuthScreen(vm: PravaViewModel) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var create by remember { mutableStateOf(false) }
    val error by vm.error.collectAsState()
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("▶ PravaTube", color = AppRed, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold)
        Text("Watch. Create. Share.", color = Color.LightGray)
        Spacer(Modifier.height(26.dp))
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
        Button(onClick = { if (create) vm.register(email.trim(), password) else vm.login(email.trim(), password) },
            modifier = Modifier.fillMaxWidth()) { Text(if (create) "Create account" else "Sign in") }
        TextButton(onClick = { create = !create }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text(if (create) "Already have an account? Sign in" else "New here? Create account")
        }
        if (!error.isNullOrBlank()) Text(error!!, color = Color(0xFFFF8A8A))
    }
}

@Composable
fun UploadScreen(vm: PravaViewModel, modifier: Modifier = Modifier) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var thumbUri by remember { mutableStateOf<Uri?>(null) }
    val status by vm.status.collectAsState()
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { videoUri = it }
    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { thumbUri = it }
    Column(modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Create and upload", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(title, { title = it }, label = { Text("Video title") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(description, { description = it }, label = { Text("Description") },
            modifier = Modifier.fillMaxWidth(), minLines = 3)
        OutlinedButton(onClick = { videoPicker.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.VideoLibrary, null); Spacer(Modifier.width(8.dp))
            Text(if (videoUri == null) "Choose video" else "Video selected")
        }
        OutlinedButton(onClick = { imagePicker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Image, null); Spacer(Modifier.width(8.dp))
            Text(if (thumbUri == null) "Choose thumbnail" else "Thumbnail selected")
        }
        Button(enabled = title.isNotBlank() && videoUri != null,
            onClick = { vm.uploadVideo(videoUri!!, thumbUri, title.trim(), description.trim()) },
            modifier = Modifier.fillMaxWidth()) { Text("Upload video") }
        if (status.isNotBlank()) Text(status, color = Color(0xFF9BE7A5))
    }
}

@Composable
fun VideoPlayerScreen(video: Video, onBack: () -> Unit, vm: PravaViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(video.videoUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.videoUrl))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text("PravaTube", fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
        AndroidView(factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f))
        Text(video.title, Modifier.padding(14.dp), fontSize = 19.sp, fontWeight = FontWeight.Bold)
        Text("${video.channelName} • ${video.views} views",
            Modifier.padding(horizontal = 14.dp), color = Color.LightGray)
        Row(Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = { vm.like(video.id) }) {
                Icon(Icons.Default.ThumbUp, null); Text(" Like")
            }
            OutlinedButton(onClick = {
                vm.download(context, video.videoUrl, "video/mp4",
                    "${safeName(video.title)}.mp4", false)
            }) {
                Icon(Icons.Default.Download, null); Text(" Download")
            }
        }
        Text(video.description, Modifier.padding(14.dp), color = Color.LightGray)
    }
}

@Composable
fun DownloadCenter(videos: List<Video>, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text("Downloads", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Text("Download videos you own or are authorized to save.",
            color = Color.LightGray, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp))
        if (videos.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No downloadable videos yet.", color = Color.LightGray)
            }
        } else {
            LazyColumn {
                items(videos, key = { it.id }) { video ->
                    Column(Modifier.fillMaxWidth().padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(video.thumbnailUrl, null,
                                Modifier.size(104.dp, 65.dp).background(SurfaceDark), contentScale = ContentScale.Crop)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(video.title, fontWeight = FontWeight.SemiBold, maxLines = 2)
                                Text(video.channelName, color = Color.LightGray, fontSize = 12.sp)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                if (video.videoUrl.isNotBlank()) {
                                    enqueueDownload(context, video.videoUrl, "${safeName(video.title)}.mp4",
                                        Environment.DIRECTORY_MOVIES + "/PravaTube", "video/mp4")
                                }
                            }, enabled = video.videoUrl.isNotBlank()) {
                                Icon(Icons.Default.Download, null); Text("Video")
                            }
                            OutlinedButton(onClick = {
                                if (video.audioUrl.isNotBlank()) {
                                    enqueueDownload(context, video.audioUrl, "${safeName(video.title)}.mp3",
                                        Environment.DIRECTORY_MUSIC + "/PravaTube", "audio/mpeg")
                                }
                            }, enabled = video.audioUrl.isNotBlank()) {
                                Icon(Icons.Default.MusicNote, null); Text("Audio")
                            }
                        }
                        Text("Audio download appears only when the creator provides an authorized audio file.",
                            color = Color.Gray, fontSize = 10.sp)
                    }
                    HorizontalDivider(color = SurfaceDark)
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(vm: PravaViewModel, modifier: Modifier = Modifier) {
    val user by vm.user.collectAsState()
    Column(modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(Icons.Default.AccountCircle, null, Modifier.size(76.dp), tint = Color.LightGray)
        Text(user?.email ?: "Your account", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text("Your PravaTube account and channel.")
        Button(onClick = { vm.signOut() }) { Text("Sign out") }
    }
}

fun safeName(value: String): String = value
    .replace(Regex("[^A-Za-z0-9._-]"), "_")
    .take(70)
    .ifBlank { "PravaTube_video" }

fun enqueueDownload(context: Context, url: String, fileName: String,
                    directory: String, mimeType: String) {
    val request = DownloadManager.Request(Uri.parse(url))
        .setTitle(fileName)
        .setDescription("Downloading with PravaTube")
        .setMimeType(mimeType)
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setAllowedOverMetered(true)
        .setAllowedOverRoaming(false)
        .setDestinationInExternalPublicDir(directory, fileName)
    val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    manager.enqueue(request)
}
