# PravaTube V2 — Android UI + real file download starter

## इस वर्जन में
- YouTube से परिचित dark interface layout: top app bar, category chips, video feed, bottom navigation
- PravaTube नाम पर क्लिक करने से Download Center
- Video player और real Android DownloadManager integration
- Video files: `Movies/PravaTube/`
- Audio files: `Music/PravaTube/`
- Firebase email/password authentication, Firestore feed, Firebase Storage upload
- Shorts tab का शुरुआती feed placeholder
- Video/Audio download buttons केवल तब सक्रिय होते हैं जब संबंधित direct media URL मौजूद हो

## सेटअप
1. Android Studio में इस folder को Open करें।
2. Firebase Console में project बनाएं और Android app package `com.pravanshu.pravatube` जोड़ें।
3. Firebase Authentication में Email/Password enable करें।
4. Firestore और Storage enable करें।
5. `google-services.json` को `app/google-services.json` में रखें।
6. `firestore.rules` और `storage.rules` publish करें।
7. Gradle Sync और Run करें।

## Real download व्यवहार
DownloadManager असली HTTP(S) media URL को डाउनलोड करता है और Android की public Movies/Music library में सेव करता है। डाउनलोड की progress और completion Android के system notification से दिखाई जाती है। इस starter में in-app pause/resume/history dashboard अभी नहीं जोड़ा गया है।

## महत्वपूर्ण
- Video download सिर्फ अपने या डाउनलोड की अनुमति वाले direct media URLs के लिए है।
- Audio download के लिए Firestore video document में `audioUrl` field में अलग authorized audio file URL होना चाहिए। वीडियो से audio निकालने या YouTube content को rip करने की सुविधा नहीं है।
- YouTube search integration इस build में अभी शामिल नहीं है। YouTube Data API और official embedded player को अलग, YouTube API Services terms के अनुरूप जोड़ना होगा।
- UI YouTube से परिचित है, लेकिन YouTube का exact proprietary branding/assets copy नहीं करता।
- यह development starter है, production-ready YouTube clone नहीं। Comments, subscriptions, shorts playback/vertical gestures, playlists, notifications, live streaming, moderation, analytics, admin panel, transcoding, search indexing, rate limits और robust security अभी बाकी हैं।
- Cloud Storage/Firestore/Cloud Run/Transcoder usage पर खर्च हो सकता है। Firebase service account credentials APK में कभी न रखें।
